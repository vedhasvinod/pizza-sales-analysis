
# 🍕 Pizza Sales Data Analysis Project

## 📊 Overview
This project analyzes pizza sales data using SQL queries and Excel dashboard visualizations to uncover key business insights including:
- Total revenue and order value
- Sales performance by category and size
- Best and worst selling pizzas
- Hourly and daily trends

## 🛠️ Tools Used
- Microsoft Excel (for dashboards)
- SQL (for data querying)

## 📁 Project Files
- 📂 [Excel File](data/PizzaSalesProject.xlsx)
- 📄 [SQL Queries](sql/pizza_sql_queries.pdf)
- 📊 [Dashboard Preview](visuals/dashboard_screenshot.png)

## 📜 Certifications
- [IBM SQL for Data Science Certificate](https://courses.edx.org/certificates/a03ee56ea5bc41d7a368ca9e26ab531a)
- [Google Data Analytics Certificate](https://coursera.org/verify/professional-cert/99J1MPKTU9KW)

## 👨‍🎓 About Me
I’m Vedhas Vinod, a Data Science student at Rutgers University (Class of 2027). I’m passionate about using data to solve real-world problems and uncover actionable insights through analytics and visualization.

## 🔗 Connect
- GitHub: [vedhasvinod](https://github.com/vedhasvinod)
- LinkedIn: [Vedhas Vinod](https://www.linkedin.com/in/vedhas-vinod-a630a1302)
